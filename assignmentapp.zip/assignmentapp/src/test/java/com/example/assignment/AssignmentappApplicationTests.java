package com.example.assignment;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignmentappApplicationTests {


}
