package com.example.assignment.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.assignment.entity.User;
import com.example.assignment.exception.ResourceNotFoundException;
import com.example.assignment.repository.UserRepository;
import com.example.assignment.response.SecureProcess;
import com.example.assignment.service.UserService;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserRepository repo;

	@Override
	public Iterable<User> getAllUsers() {
		return repo.findAll();
	}

	@Override
	public User saveUser(User user) {
		user.setPassword(SecureProcess.encrypt(user.getPassword()));
		return repo.save(user);
	}
	
	@Override
	public User updateUser(Long id, User user) throws ResourceNotFoundException {
		user.setPassword(SecureProcess.encrypt(user.getPassword()));
		User user2 = getUserById(id);
		user.setId(user2.getId());
		return repo.save(user);
	}

	@Override
	public User getUserById(Long id) throws ResourceNotFoundException {
		return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("User not found for this id :: " + id));
	}

	@Override
	public Map<String, Boolean> removeUserById(Long id) throws ResourceNotFoundException {
		Map<String, Boolean> response = new HashMap<>();
		User optional = getUserById(id);
		if(optional!=null) {
			repo.delete(optional);
			response.put("deleted", Boolean.TRUE);
		}else{
			response.put("deleted", Boolean.FALSE);
		}
		return response;
	}

	@Override
	public User getUserByValidUsernameAndPassword(String username, String password) {
		User user = repo.findByUsernameAndPassword(username, SecureProcess.encrypt(password));
		return user;
	}

}
