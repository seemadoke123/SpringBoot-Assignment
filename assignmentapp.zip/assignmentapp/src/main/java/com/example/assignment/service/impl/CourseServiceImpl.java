package com.example.assignment.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.assignment.entity.Course;
import com.example.assignment.exception.ResourceNotFoundException;
import com.example.assignment.repository.CourseRepository;
import com.example.assignment.service.CourseService;

@Service
public class CourseServiceImpl implements CourseService{
	
	@Autowired
	CourseRepository repo;

	@Override
	public Iterable<Course> getAllCourses() {
		return repo.findAll();
	}

	@Override
	public Course saveCourse(Course course) {
		return repo.save(course);
	}
	
	@Override
	public Course updateCourse(Long id, Course course) throws ResourceNotFoundException {
		Course course2 = getCourseById(id);
		course.setId(course2.getId());
		return repo.save(course);
	}

	@Override
	public Course getCourseById(Long id) throws ResourceNotFoundException {
		return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Course not found for this id :: " + id));
	}

	@Override
	public Map<String, Boolean> removeCourseById(Long id) throws ResourceNotFoundException {
		Map<String, Boolean> response = new HashMap<>();
		Course optional = getCourseById(id);
		if(optional!=null) {
			repo.delete(optional);
			response.put("deleted", Boolean.TRUE);
		}else{
			response.put("deleted", Boolean.FALSE);
		}
		return response;
	}

}
