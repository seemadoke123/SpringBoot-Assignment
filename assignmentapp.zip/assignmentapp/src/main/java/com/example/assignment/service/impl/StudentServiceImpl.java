package com.example.assignment.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.assignment.entity.Student;
import com.example.assignment.exception.ResourceNotFoundException;
import com.example.assignment.repository.StudentRepository;
import com.example.assignment.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService{
	
	@Autowired
	StudentRepository repo;

	@Override
	public Iterable<Student> getAllStudents() {
		return repo.findAll();
	}

	@Override
	public Student saveStudent(Student student) {
		return repo.save(student);
	}
	
	@Override
	public Student updateStudent(Long id, Student student) throws ResourceNotFoundException {
		Student student2 = getStudentById(id);
		student.setId(student2.getId());
		return repo.save(student);
	}

	@Override
	public Student getStudentById(Long id) throws ResourceNotFoundException {
		return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Student not found for this id :: " + id));
	}

	@Override
	public Map<String, Boolean> removeStudentById(Long id) throws ResourceNotFoundException {
		Map<String, Boolean> response = new HashMap<>();
		Student optional = getStudentById(id);
		if(optional!=null) {
			repo.delete(optional);
			response.put("deleted", Boolean.TRUE);
		}else{
			response.put("deleted", Boolean.FALSE);
		}
		return response;
	}

}
