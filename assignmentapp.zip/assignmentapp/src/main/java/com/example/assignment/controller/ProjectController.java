package com.example.assignment.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.assignment.entity.Project;
import com.example.assignment.exception.ResourceNotFoundException;
import com.example.assignment.service.ProjectService;

/**
*
* @author Seema Doke
*/
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/projects")
public class ProjectController {
	
private static final Logger logger = LoggerFactory.getLogger(ProjectController.class);
	
	@Autowired
	ProjectService projectService;
	
	@GetMapping("")
	public Iterable<Project> showList(){
		logger.debug("inside ProjectController.showList() method");
		Iterable<Project> list = projectService.getAllProjects();
		return list;
	}
	
	
	@PostMapping("")
	public ResponseEntity<Project> saveProject(@Valid @RequestBody Project project){
		logger.debug("inside ProjectController.saveProject() method");
		Project project2 = projectService.saveProject(project);
		return ResponseEntity.ok().body(project2);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Project> updateProject(@PathVariable(value = "id") Long projectId, @RequestBody Project project) throws ResourceNotFoundException{
		logger.debug("inside ProjectController.updateProject() method");
		Project project2 = projectService.updateProject(projectId, project);
		return ResponseEntity.ok().body(project2);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Project> getProjectById(@PathVariable(value = "id") Long projectId) throws ResourceNotFoundException{
		logger.debug("inside ProjectController.getProjectById() method");
		Project project = projectService.getProjectById(projectId);
		return ResponseEntity.ok().body(project);
	}
	
	@DeleteMapping("/{id}")
	public Map<String, Boolean> deleteProject(@PathVariable(value = "id") Long projectId) throws ResourceNotFoundException {
		logger.debug("inside ProjectController.deleteProject() method: "+projectId );
		Map<String, Boolean> response = new HashMap<String, Boolean>();
		try {
			response = projectService.removeProjectById(projectId);
		} catch (Exception e) {
			new ResourceNotFoundException("Not deleted");
		}
		return response;
	}

}
