package com.example.assignment.service;

import java.util.Map;

import com.example.assignment.entity.Course;
import com.example.assignment.exception.ResourceNotFoundException;

public interface CourseService {
	
	public Iterable<Course> getAllCourses();

	public Course saveCourse(Course course);

	public Course updateCourse(Long id, Course course) throws ResourceNotFoundException;

	public Course getCourseById(Long id) throws ResourceNotFoundException;

	public Map<String, Boolean> removeCourseById(Long id) throws ResourceNotFoundException;
}
