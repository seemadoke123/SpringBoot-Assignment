package com.example.assignment.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.assignment.entity.Product;
import com.example.assignment.exception.ResourceNotFoundException;
import com.example.assignment.service.ProductService;


/**
*
* @author Seema Doke
*/
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/products")
public class ProductController {
	
private static final Logger logger = LoggerFactory.getLogger(ProductController.class);
	
	@Autowired
	ProductService productService;
	
	@GetMapping("")
	public Iterable<Product> showList(){
		logger.debug("inside ProductController.showList() method");
		Iterable<Product> list = productService.getAllProducts();
		return list;
	}
	
	
	@PostMapping("")
	public ResponseEntity<Product> saveProduct(@Valid @RequestBody Product product){
		logger.debug("inside ProductController.saveProduct() method");
		Product product2 = productService.saveProduct(product);
		return ResponseEntity.ok().body(product2);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Product> updateProduct(@PathVariable(value = "id") Long productId, @RequestBody Product product) throws ResourceNotFoundException{
		logger.debug("inside ProductController.updateProduct() method");
		Product product2 = productService.updateProduct(productId, product);
		return ResponseEntity.ok().body(product2);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Product> getProductById(@PathVariable(value = "id") Long productId) throws ResourceNotFoundException{
		logger.debug("inside ProductController.getProductById() method");
		Product product = productService.getProductById(productId);
		return ResponseEntity.ok().body(product);
	}
	
	@DeleteMapping("/{id}")
	public Map<String, Boolean> deleteProduct(@PathVariable(value = "id") Long productId) throws ResourceNotFoundException {
		logger.debug("inside ProductController.deleteProduct() method: "+productId );
		Map<String, Boolean> response = new HashMap<String, Boolean>();
		try {
			response = productService.removeProductById(productId);
		} catch (Exception e) {
			new ResourceNotFoundException("Not deleted");
		}
		return response;
	}

}
