package com.example.assignment.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.assignment.entity.Bus;
import com.example.assignment.exception.ResourceNotFoundException;
import com.example.assignment.repository.BusRepository;
import com.example.assignment.service.BusService;

@Service
public class BusServiceImpl implements BusService{
	
	@Autowired
	BusRepository repo;

	@Override
	public Iterable<Bus> getAllBuss() {
		return repo.findAll();
	}

	@Override
	public Bus saveBus(Bus bus) {
		return repo.save(bus);
	}
	
	@Override
	public Bus updateBus(Long id, Bus bus) throws ResourceNotFoundException {
		Bus bus2 = getBusById(id);
		bus.setId(bus2.getId());
		return repo.save(bus);
	}

	@Override
	public Bus getBusById(Long id) throws ResourceNotFoundException {
		return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Bus not found for this id :: " + id));
	}

	@Override
	public Map<String, Boolean> removeBusById(Long id) throws ResourceNotFoundException {
		Map<String, Boolean> response = new HashMap<>();
		Bus optional = getBusById(id);
		if(optional!=null) {
			repo.delete(optional);
			response.put("deleted", Boolean.TRUE);
		}else{
			response.put("deleted", Boolean.FALSE);
		}
		return response;
	}

}
