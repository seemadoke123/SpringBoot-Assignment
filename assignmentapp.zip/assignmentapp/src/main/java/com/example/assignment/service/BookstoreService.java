package com.example.assignment.service;

import java.util.Map;

import com.example.assignment.entity.Bookstore;
import com.example.assignment.exception.ResourceNotFoundException;

public interface BookstoreService {
	
	public Iterable<Bookstore> getAllBookstores();
	
	public Bookstore saveBookstore(Bookstore bookstore);
	
	public Bookstore updateBookstore(Long id, Bookstore bookstore) throws ResourceNotFoundException;
	
	public Bookstore getBookstoreById(Long id) throws ResourceNotFoundException;

	public Map<String, Boolean> removeBookstoreById(Long id) throws ResourceNotFoundException;
}
