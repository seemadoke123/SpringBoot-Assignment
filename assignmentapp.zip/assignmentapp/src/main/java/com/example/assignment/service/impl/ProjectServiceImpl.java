package com.example.assignment.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.assignment.entity.Project;
import com.example.assignment.exception.ResourceNotFoundException;
import com.example.assignment.repository.ProjectRepository;
import com.example.assignment.service.ProjectService;

@Service
public class ProjectServiceImpl implements ProjectService{
	
	@Autowired
	ProjectRepository repo;

	@Override
	public Iterable<Project> getAllProjects() {
		return repo.findAll();
	}

	@Override
	public Project saveProject(Project project) {
		return repo.save(project);
	}
	
	@Override
	public Project updateProject(Long id, Project project) throws ResourceNotFoundException {
		Project project2 = getProjectById(id);
		project.setId(project2.getId());
		return repo.save(project);
	}

	@Override
	public Project getProjectById(Long id) throws ResourceNotFoundException {
		return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Project not found for this id :: " + id));
	}

	@Override
	public Map<String, Boolean> removeProjectById(Long id) throws ResourceNotFoundException {
		Map<String, Boolean> response = new HashMap<>();
		Project optional = getProjectById(id);
		if(optional!=null) {
			repo.delete(optional);
			response.put("deleted", Boolean.TRUE);
		}else{
			response.put("deleted", Boolean.FALSE);
		}
		return response;
	}

}
