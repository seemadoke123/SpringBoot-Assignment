package com.example.assignment.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.assignment.entity.Bookstore;
import com.example.assignment.exception.ResourceNotFoundException;
import com.example.assignment.repository.BookstoreRepository;
import com.example.assignment.service.BookstoreService;

@Service
public class BookstoreServiceImpl implements BookstoreService{
	
	@Autowired
	BookstoreRepository repo;

	@Override
	public Iterable<Bookstore> getAllBookstores() {
		return repo.findAll();
	}

	@Override
	public Bookstore saveBookstore(Bookstore bookstore) {
		return repo.save(bookstore);
	}
	
	@Override
	public Bookstore updateBookstore(Long id, Bookstore bookstore) throws ResourceNotFoundException {
		Bookstore bookstore2 = getBookstoreById(id);
		bookstore.setId(bookstore2.getId());
		return repo.save(bookstore);
	}

	@Override
	public Bookstore getBookstoreById(Long id) throws ResourceNotFoundException {
		return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Bookstore not found for this id :: " + id));
	}

	@Override
	public Map<String, Boolean> removeBookstoreById(Long id) throws ResourceNotFoundException {
		Map<String, Boolean> response = new HashMap<>();
		Bookstore optional = getBookstoreById(id);
		if(optional!=null) {
			repo.delete(optional);
			response.put("deleted", Boolean.TRUE);
		}else{
			response.put("deleted", Boolean.FALSE);
		}
		return response;
	}

}

