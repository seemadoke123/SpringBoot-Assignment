package com.example.assignment.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.assignment.entity.Transaction;
import com.example.assignment.exception.ResourceNotFoundException;
import com.example.assignment.repository.TransactionRepository;
import com.example.assignment.service.TransactionService;

@Service
public class TransactionServiceImpl implements TransactionService{
	
	@Autowired
	TransactionRepository repo;

	@Override
	public Iterable<Transaction> getAllTransactions() {
		return repo.findAll();
	}

	@Override
	public Transaction saveTransaction(Transaction transaction) {
		return repo.save(transaction);
	}
	
	@Override
	public Transaction updateTransaction(Long id, Transaction transaction) throws ResourceNotFoundException {
		Transaction transaction2 = getTransactionById(id);
		transaction.setId(transaction2.getId());
		return repo.save(transaction);
	}

	@Override
	public Transaction getTransactionById(Long id) throws ResourceNotFoundException {
		return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Transaction not found for this id :: " + id));
	}

	@Override
	public Map<String, Boolean> removeTransactionById(Long id) throws ResourceNotFoundException {
		Map<String, Boolean> response = new HashMap<>();
		Transaction optional = getTransactionById(id);
		if(optional!=null) {
			repo.delete(optional);
			response.put("deleted", Boolean.TRUE);
		}else{
			response.put("deleted", Boolean.FALSE);
		}
		return response;
	}

}
