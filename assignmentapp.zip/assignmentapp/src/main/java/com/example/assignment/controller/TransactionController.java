package com.example.assignment.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.assignment.entity.Transaction;
import com.example.assignment.exception.ResourceNotFoundException;
import com.example.assignment.service.TransactionService;


/**
*
* @author Seema Doke
*/
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/transactions")
public class TransactionController {
	
private static final Logger logger = LoggerFactory.getLogger(TransactionController.class);
	
	@Autowired
	TransactionService transactionService;
	
	@GetMapping("")
	public Iterable<Transaction> showList(){
		logger.debug("inside TransactionController.showList() method");
		Iterable<Transaction> list = transactionService.getAllTransactions();
		return list;
	}
	
	
	@PostMapping("")
	public ResponseEntity<Transaction> saveTransaction(@Valid @RequestBody Transaction transaction){
		logger.debug("inside TransactionController.saveTransaction() method");
		Transaction transaction2 = transactionService.saveTransaction(transaction);
		return ResponseEntity.ok().body(transaction2);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Transaction> updateTransaction(@PathVariable(value = "id") Long transactionId, @RequestBody Transaction transaction) throws ResourceNotFoundException{
		logger.debug("inside TransactionController.updateTransaction() method");
		Transaction transaction2 = transactionService.updateTransaction(transactionId, transaction);
		return ResponseEntity.ok().body(transaction2);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Transaction> getTransactionById(@PathVariable(value = "id") Long transactionId) throws ResourceNotFoundException{
		logger.debug("inside TransactionController.getTransactionById() method");
		Transaction transaction = transactionService.getTransactionById(transactionId);
		return ResponseEntity.ok().body(transaction);
	}
	
	@DeleteMapping("/{id}")
	public Map<String, Boolean> deleteTransaction(@PathVariable(value = "id") Long transactionId) throws ResourceNotFoundException {
		logger.debug("inside TransactionController.deleteTransaction() method: "+transactionId );
		Map<String, Boolean> response = new HashMap<String, Boolean>();
		try {
			response = transactionService.removeTransactionById(transactionId);
		} catch (Exception e) {
			new ResourceNotFoundException("Not deleted");
		}
		return response;
	}

}
