package com.example.assignment.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "project")
public class Project {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name="projectname")
	private String projectName;

	@Column(name="dateofstart")
	private Date dateOfStart;
	
	@Column(name="teamsize")
	private Integer teamSize;
	

	public Project() {
		super();
	}


	public Long getId() {
		return id;
	}


	public void setId(Long projectid) {
		this.id = projectid;
	}


	public String getProjectName() {
		return projectName;
	}


	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}


	public Date getDateOfStart() {
		return dateOfStart;
	}


	public void setDateOfStart(Date dateOfStart) {
		this.dateOfStart = dateOfStart;
	}


	public Integer getTeamSize() {
		return teamSize;
	}


	public void setTeamSize(Integer teamSize) {
		this.teamSize = teamSize;
	}

}
