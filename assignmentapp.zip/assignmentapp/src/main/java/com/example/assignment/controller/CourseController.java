package com.example.assignment.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.assignment.entity.Course;
import com.example.assignment.exception.ResourceNotFoundException;
import com.example.assignment.service.CourseService;


/**
*
* @author Seema Doke
*/
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/courses")
public class CourseController {
	
private static final Logger logger = LoggerFactory.getLogger(CourseController.class);
	
	@Autowired
	CourseService courseService;
	
	@GetMapping("")
	public Iterable<Course> showList(){
		logger.debug("inside CourseController.showList() method");
		Iterable<Course> list = courseService.getAllCourses();
		return list;
	}
	
	
	@PostMapping("")
	public ResponseEntity<Course> saveCourse(@Valid @RequestBody Course course){
		logger.debug("inside CourseController.saveCourse() method");
		Course course2 = courseService.saveCourse(course);
		return ResponseEntity.ok().body(course2);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Course> updateCourse(@PathVariable(value = "id") Long courseId, @RequestBody Course course) throws ResourceNotFoundException{
		logger.debug("inside CourseController.updateCourse() method");
		Course course2 = courseService.updateCourse(courseId, course);
		return ResponseEntity.ok().body(course2);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Course> getCourseById(@PathVariable(value = "id") Long courseId) throws ResourceNotFoundException{
		logger.debug("inside CourseController.getCourseById() method");
		Course course = courseService.getCourseById(courseId);
		return ResponseEntity.ok().body(course);
	}
	
	@DeleteMapping("/{id}")
	public Map<String, Boolean> deleteCourse(@PathVariable(value = "id") Long courseId) throws ResourceNotFoundException {
		logger.debug("inside CourseController.deleteCourse() method: "+courseId );
		Map<String, Boolean> response = new HashMap<String, Boolean>();
		try {
			response = courseService.removeCourseById(courseId);
		} catch (Exception e) {
			new ResourceNotFoundException("Not deleted");
		}
		return response;
	}

}
