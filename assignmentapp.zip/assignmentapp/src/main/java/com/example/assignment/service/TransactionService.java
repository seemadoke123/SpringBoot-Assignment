package com.example.assignment.service;

import java.util.Map;

import com.example.assignment.entity.Transaction;
import com.example.assignment.exception.ResourceNotFoundException;

public interface TransactionService {
	
	public Iterable<Transaction> getAllTransactions();
	
	public Transaction saveTransaction(Transaction transaction);
	
	public Transaction updateTransaction(Long id, Transaction transaction) throws ResourceNotFoundException;
	
	public Transaction getTransactionById(Long id) throws ResourceNotFoundException;

	public Map<String, Boolean> removeTransactionById(Long id) throws ResourceNotFoundException;
}
