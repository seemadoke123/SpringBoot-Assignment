package com.example.assignment.service;

import java.util.Map;

import com.example.assignment.entity.Product;
import com.example.assignment.exception.ResourceNotFoundException;

public interface ProductService {

	public Iterable<Product> getAllProducts();
	
	public Product saveProduct(Product product);
	
	public Product updateProduct(Long id, Product product) throws ResourceNotFoundException;
	
	public Product getProductById(Long id) throws ResourceNotFoundException;

	public Map<String, Boolean> removeProductById(Long id) throws ResourceNotFoundException;
}
