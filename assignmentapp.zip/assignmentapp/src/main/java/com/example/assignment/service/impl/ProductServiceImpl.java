package com.example.assignment.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.assignment.entity.Product;
import com.example.assignment.exception.ResourceNotFoundException;
import com.example.assignment.repository.ProductRepository;
import com.example.assignment.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	ProductRepository repo;

	@Override
	public Iterable<Product> getAllProducts() {
		return repo.findAll();
	}

	@Override
	public Product saveProduct(Product product) {
		return repo.save(product);
	}
	
	@Override
	public Product updateProduct(Long id, Product product) throws ResourceNotFoundException {
		Product product2 = getProductById(id);
		product.setId(product2.getId());
		return repo.save(product);
	}

	@Override
	public Product getProductById(Long id) throws ResourceNotFoundException {
		return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product not found for this id :: " + id));
	}

	@Override
	public Map<String, Boolean> removeProductById(Long id) throws ResourceNotFoundException {
		Map<String, Boolean> response = new HashMap<>();
		Product optional = getProductById(id);
		if(optional!=null) {
			repo.delete(optional);
			response.put("deleted", Boolean.TRUE);
		}else{
			response.put("deleted", Boolean.FALSE);
		}
		return response;
	}

}
