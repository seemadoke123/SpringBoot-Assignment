package com.example.assignment.service;

import java.util.Map;

import com.example.assignment.entity.Student;
import com.example.assignment.exception.ResourceNotFoundException;

public interface StudentService {
	
	public Iterable<Student> getAllStudents();
	
	public Student saveStudent(Student student);
	
	public Student updateStudent(Long id, Student student) throws ResourceNotFoundException;
	
	public Student getStudentById(Long id) throws ResourceNotFoundException;

	public Map<String, Boolean> removeStudentById(Long id) throws ResourceNotFoundException;
}
