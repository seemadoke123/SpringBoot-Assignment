package com.example.assignment.service;

import java.util.Map;

import com.example.assignment.entity.Bus;
import com.example.assignment.exception.ResourceNotFoundException;

public interface BusService {
	
	public Iterable<Bus> getAllBuss();
	
	public Bus saveBus(Bus bus);
	
	public Bus updateBus(Long id, Bus bus) throws ResourceNotFoundException;
	
	public Bus getBusById(Long id) throws ResourceNotFoundException;

	public Map<String, Boolean> removeBusById(Long id) throws ResourceNotFoundException;
}
