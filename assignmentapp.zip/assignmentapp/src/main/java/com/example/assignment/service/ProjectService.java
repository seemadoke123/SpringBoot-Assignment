package com.example.assignment.service;

import java.util.Map;

import com.example.assignment.entity.Project;
import com.example.assignment.exception.ResourceNotFoundException;

public interface ProjectService {
	
	public Iterable<Project> getAllProjects();
	
	public Project saveProject(Project project);
	
	public Project updateProject(Long id, Project project) throws ResourceNotFoundException;
	
	public Project getProjectById(Long id) throws ResourceNotFoundException;

	public Map<String, Boolean> removeProjectById(Long id) throws ResourceNotFoundException;
}
