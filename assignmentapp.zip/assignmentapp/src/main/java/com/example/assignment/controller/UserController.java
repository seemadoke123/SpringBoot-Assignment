package com.example.assignment.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.assignment.entity.User;
import com.example.assignment.exception.ResourceNotFoundException;
import com.example.assignment.service.UserService;


/**
*
* @author Seema Doke
*/
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/users")
public class UserController {
	
private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	UserService userService;
	
	@GetMapping("")
	public Iterable<User> showList(){
		logger.debug("inside UserController.showList() method");
		Iterable<User> list = userService.getAllUsers();
		return list;
	}
	
	
	@PostMapping("")
	public ResponseEntity<User> saveUser(@Valid @RequestBody User user){
		logger.debug("inside UserController.saveUser() method");
		User user2 = userService.saveUser(user);
		return ResponseEntity.ok().body(user2);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<User> updateUser(@PathVariable(value = "id") Long userId, @RequestBody User user) throws ResourceNotFoundException{
		logger.debug("inside UserController.updateUser() method");
		User user2 = userService.updateUser(userId, user);
		return ResponseEntity.ok().body(user2);
	}

	@GetMapping("/{id}")
	public ResponseEntity<User> getUserById(@PathVariable(value = "id") Long userId) throws ResourceNotFoundException{
		logger.debug("inside UserController.getUserById() method");
		User user = userService.getUserById(userId);
		return ResponseEntity.ok().body(user);
	}
	
	@DeleteMapping("/{id}")
	public Map<String, Boolean> deleteUser(@PathVariable(value = "id") Long userId) throws ResourceNotFoundException {
		logger.debug("inside UserController.deleteUser() method: "+userId );
		Map<String, Boolean> response = new HashMap<String, Boolean>();
		try {
			response = userService.removeUserById(userId);
		} catch (Exception e) {
			new ResourceNotFoundException("Not deleted");
		}
		return response;
	}
	
	@GetMapping("/validatepassword")
	public ResponseEntity<User> validateUser(@RequestParam("username") String username, @RequestParam("password") String password) throws ResourceNotFoundException {
		User user = userService.getUserByValidUsernameAndPassword(username, password);
		return ResponseEntity.ok().body(user);
	}

}
