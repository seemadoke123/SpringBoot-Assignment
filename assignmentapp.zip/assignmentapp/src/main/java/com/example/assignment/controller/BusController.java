package com.example.assignment.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.assignment.entity.Bus;
import com.example.assignment.exception.ResourceNotFoundException;
import com.example.assignment.service.BusService;


/**
*
* @author Seema Doke
*/
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/bus")
public class BusController {
	
private static final Logger logger = LoggerFactory.getLogger(BusController.class);
	
	@Autowired
	BusService busService;
	
	@GetMapping("")
	public Iterable<Bus> showList(){
		logger.debug("inside BusController.showList() method");
		Iterable<Bus> list = busService.getAllBuss();
		return list;
	}
	
	
	@PostMapping("")
	public ResponseEntity<Bus> saveBus(@Valid @RequestBody Bus bus){
		logger.debug("inside BusController.saveBus() method");
		Bus bus2 = busService.saveBus(bus);
		return ResponseEntity.ok().body(bus2);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Bus> updateBus(@PathVariable(value = "id") Long busId, @RequestBody Bus bus) throws ResourceNotFoundException{
		logger.debug("inside BusController.updateBus() method");
		Bus bus2 = busService.updateBus(busId, bus);
		return ResponseEntity.ok().body(bus2);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Bus> getBusById(@PathVariable(value = "id") Long busId) throws ResourceNotFoundException{
		logger.debug("inside BusController.getBusById() method");
		Bus bus = busService.getBusById(busId);
		return ResponseEntity.ok().body(bus);
	}
	
	@DeleteMapping("/{id}")
	public Map<String, Boolean> deleteBus(@PathVariable(value = "id") Long busId) throws ResourceNotFoundException {
		logger.debug("inside BusController.deleteBus() method: "+busId );
		Map<String, Boolean> response = new HashMap<String, Boolean>();
		try {
			response = busService.removeBusById(busId);
		} catch (Exception e) {
			new ResourceNotFoundException("Not deleted");
		}
		return response;
	}

}
