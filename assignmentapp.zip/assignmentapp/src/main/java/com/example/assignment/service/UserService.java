package com.example.assignment.service;

import java.util.Map;

import com.example.assignment.entity.User;
import com.example.assignment.exception.ResourceNotFoundException;

public interface UserService {
	
	public Iterable<User> getAllUsers();
	
	public User saveUser(User user);
	
	public User updateUser(Long id, User user) throws ResourceNotFoundException;
	
	public User getUserById(Long id) throws ResourceNotFoundException;

	public Map<String, Boolean> removeUserById(Long id) throws ResourceNotFoundException;

	public User getUserByValidUsernameAndPassword(String username, String password);

}
